const bookModel=require('../models/bookModel')
const authorModel=require('../models/authorModel')
const userModel=require('../models/userModel')
const adminModel=require('../models/adminModel')
const validator=require('../Validator/validator');
const mongoose=require('mongoose');

let array=[bookModel,authorModel,userModel,adminModel]
let array2= ["book","author","user","admin"]


//***************************** GetAllData ****************************************** */

const getData=async(req,res)=>{
try{

    //************** validations ******** */

    if(!validator.isValid(req.query.model))
    return res.status(400).send({status:false,message:"please enter valid model"})

    if(!validator.isValidModel(req.query.model))
    return res.status(400).send({status:false,message:"please enter model present in db"})

    //*****End of the Validation ****/

    let index;
    for(let i=0;i<array2.length;i++){
       
        if(array2[i]==req.query.model){
         index=i
        }
    }
    let userData= await array[index].find({isDeleted:false})

    if(!userData  || userData.length<=0)
    return res.status(400).send({status:true,message:"No Such Data found"})

     return res.status(200).send({status:true,message:"data found successfully" ,data:userData})


}catch(err){
console.log(err.message)
res.status(500).send({status:false, message:err.message})
}
}


//***************************** Create New Document  ****************************************** */


const createDoc=async(req,res)=>{
    try{

        //*********** Validation **********/

   if(!validator.isValid(req.body.model))
   return res.status(400).send({status:false,message:"please enter valid model"})

   if(!validator.isValidModel(req.body.model))
    return res.status(400).send({status:false,message:"please enter model present in db"})

  if(!validator.isValidRequestBody(req.body.data))
  return res.status(400).send({status:false,message:"request body is empty"})

    //********* Ends */ 
    let index;
    for(let i=0;i<array2.length;i++){
       
        if(array2[i]==req.body.model){
         index=i
        }
    }

    let userData= await array[index].create(req.body.data)
   
    if(!userData)
    return res.status(400).send({status:true,message:"opearation unsuccessful"})

    return res.status(201).send({status:true ,message:"document created Successfully", data:userData})
                    

    }catch(err){
        console.log(err.message)
        res.status(500).send({status:false,message:err.message})
    }
}


//***************************** Delete Any Document  ****************************************** */

const deleteDoc=async(req,res)=>{
    try{
   const docId=req.query.docId

   //*********** Validation **********/

   if(!validator.isValid(req.query.model))
   return res.status(400).send({status:false,message:"please enter valid model"})

   if(!validator.isValidObjectId(docId))
   return res.status(400).send({status:false,message:"Please enter the Valid DocId"})

   if(!validator.isValidModel(req.query.model))
    return res.status(400).send({status:false,message:"please enter model present in db"})

    //********* Ends */

    let index;
    for(let i=0;i<array2.length;i++){
       
        if(array2[i]==req.query.model){
         index=i
        }
    }
    let userData= await array[index].findByIdAndUpdate({ _id: docId }, { $set: { isDeleted: true, deletedAt: Date() } }, { new: true })
        
    if(!userData)
        return res.status(400).send({status:false,message:"Document does not found"})

        res.status(200).send({status:true,message:"Data Deleted Successfully"})

    }
    catch(err){
        console.log(err.message)
        res.status(500).send({status:false,message:err.message})
    }
}

//***************************** Update Any Document  ****************************************** */

const UpdateDoc=async(req,res)=>{
    try{
     const docId=req.query.id 
     const model=req.query.model
     const data=req.body

    //*********** Validation **********/

   if(!validator.isValid(model))
   return res.status(400).send({status:false,message:"please enter valid model"})

   if(!validator.isValidObjectId(docId))
   return res.status(400).send({status:false,message:"Please enter the Valid DocId"})

   if(!validator.isValidModel(model))
    return res.status(400).send({status:false,message:"please enter model present in db"})

  if(!validator.isValidRequestBody(data))
  return res.status(400).send({status:false,message:"request body is empty"})

    //********* Ends */ 
    
     let index;
     for(let i=0;i<array2.length;i++){
        
         if(array2[i]==req.query.model){
          index=i
         }
     }

     let userData= await array[index].findByIdAndUpdate({_id:docId,isDeleted:false},data,{new:true})

         if(!userData)
         return res.status(400).send({status:false,message:"unable to find Document with this id"})

         console.log(userData)
         res.status(201).send({status:true,message:"Document Updated Successfully", data:userData })

    }
    catch(err){
        console.log(err.message)
        res.status(500).send({status:false,message:err.message})
    }
}


module.exports={ getData, createDoc, deleteDoc , UpdateDoc }